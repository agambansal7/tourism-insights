"use client"

import { useEffect } from 'react';
import { useYearSelection, useRegionSelection } from '@/hooks/useInteractiveElements';
import { YearSlider, FilterPanel, Tooltip } from '@/components/interactive';
import InteractiveDashboard from '@/components/dashboard/InteractiveDashboard';
import Link from 'next/link';
import Image from 'next/image';

export default function DirectFlightsPage() {
  const { selectedYear, setSelectedYear, availableYears } = useYearSelection('2019');
  const { selectedRegion, setSelectedRegion, availableRegions } = useRegionSelection();
  
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-blue-600 text-white py-6">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <Link href="/" className="text-2xl font-bold">Global Tourism Insights</Link>
            <nav className="flex gap-6">
              <Link href="/tourism-trends" className="font-semibold">Tourism Trends</Link>
              <Link href="/direct-flights" className="font-semibold underline">Direct Flights Impact</Link>
              <Link href="/currency-impact" className="font-semibold">Currency Strength Impact</Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        {/* Section Header */}
        <section className="bg-blue-50 py-12">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl font-bold mb-4">Direct Flights Influence on Tourism</h1>
            <p className="text-xl text-gray-600">
              Discover how the availability of direct flights correlates with tourism growth across different regions.
            </p>
          </div>
        </section>

        {/* Filters Panel */}
        <section className="py-6 bg-white border-b">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap gap-6 items-end">
              <div className="w-full max-w-xs">
                <label className="block text-sm font-medium text-gray-700 mb-2">Year:</label>
                <YearSlider 
                  years={availableYears}
                  selectedYear={selectedYear}
                  onChange={setSelectedYear}
                />
              </div>
              
              <div className="w-full max-w-xs">
                <label className="block text-sm font-medium text-gray-700 mb-2">Region:</label>
                <select 
                  value={selectedRegion}
                  onChange={(e) => setSelectedRegion(e.target.value)}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  {availableRegions.map(region => (
                    <option key={region} value={region}>{region}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </section>

        {/* Tourism Growth Map */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="bg-white rounded-xl shadow-md p-6 mb-8">
              <h2 className="text-2xl font-bold mb-6">Tourism Growth Map ({selectedYear})</h2>
              <div className="h-[500px] relative">
                <Image 
                  src="/images/slide_11_image_1.png"
                  alt="Tourism Growth Map"
                  fill
                  style={{objectFit: 'contain'}}
                  priority
                />
              </div>
              <div className="mt-4 text-gray-600">
                <p>This map shows countries with high vs. low direct flight increases. Countries in blue have experienced significant growth in direct flight connections, while countries in orange have seen more modest growth.</p>
                <p className="mt-2">The data is filtered to show information for {selectedYear} in the {selectedRegion} region.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Interactive Dashboard */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <InteractiveDashboard />
          </div>
        </section>

        {/* Flight Impact on Growth */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-2xl font-bold mb-6">Flight Impact on Tourism Growth ({selectedYear})</h2>
              <div className="h-[500px] relative">
                <Image 
                  src="/images/slide_13_image_1.png"
                  alt="Flight Impact on Tourism Growth"
                  fill
                  style={{objectFit: 'contain'}}
                />
              </div>
              <div className="mt-4 text-gray-600">
                <p>This scatter plot shows the correlation between direct flights and tourism growth for {selectedYear}. Each point represents a country, with the x-axis showing the number of direct flights and the y-axis showing tourism growth rate.</p>
                <p className="mt-2">The upward trend suggests that countries with more direct flights tend to experience higher tourism growth, particularly in the {selectedRegion} region.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Key Insights */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8">Key Insights for {selectedYear}</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Direct Flight Correlation</h3>
                <p className="text-gray-600">
                  Countries with higher growth in direct flight connections tend to experience greater increases in tourism arrivals. This suggests that expanding air connectivity can be an effective strategy for boosting tourism.
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Transport Mode Impact</h3>
                <p className="text-gray-600">
                  Air travel consistently accounts for the largest share of international tourist arrivals, highlighting the importance of aviation infrastructure for tourism development. However, land and water transport remain significant for certain regions.
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Regional Variations</h3>
                <p className="text-gray-600">
                  The impact of direct flights on tourism varies by region. Some regions show stronger correlations between flight connectivity and tourism growth, suggesting that other factors (such as visa policies, attractions, or marketing) may play more significant roles in certain areas.
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Policy Implications</h3>
                <p className="text-gray-600">
                  For tourism boards and policymakers, these findings suggest that investing in aviation infrastructure and attracting more direct flights could be an effective strategy for increasing tourism. Collaboration between tourism authorities and airlines may yield significant benefits.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <p>© 2025 Global Tourism Insights</p>
            </div>
            <div className="flex gap-8">
              <Link href="/" className="hover:underline">Home</Link>
              <Link href="/tourism-trends" className="hover:underline">Tourism Trends</Link>
              <Link href="/direct-flights" className="hover:underline">Direct Flights Impact</Link>
              <Link href="/currency-impact" className="hover:underline">Currency Strength Impact</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
