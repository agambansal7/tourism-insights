import Link from 'next/link'
import Image from 'next/image'

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-teal-500 text-white py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl font-bold mb-6">Global Tourism Insights</h1>
          <p className="text-xl mb-8">
            Explore interactive visualizations of global tourism trends, the influence of direct flights, 
            and the impact of currency strength on travel patterns.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link href="/tourism-trends" className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition">
              Tourism Trends
            </Link>
            <Link href="/direct-flights" className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition">
              Direct Flights Impact
            </Link>
            <Link href="/currency-impact" className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition">
              Currency Strength Impact
            </Link>
          </div>
        </div>
      </section>

      {/* Overview Cards */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">Explore Our Interactive Visualizations</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Tourism Trends Card */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image 
                  src="/images/slide_8_image_1.png" 
                  alt="Tourism Trends" 
                  fill 
                  style={{objectFit: 'cover'}}
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Tourism Trends Over the Past Decade</h3>
                <p className="text-gray-600 mb-4">
                  Explore how global tourism has evolved from 1995 to 2022, including the significant impact of COVID-19.
                </p>
                <Link href="/tourism-trends" className="text-blue-600 font-semibold hover:underline">
                  Explore Trends →
                </Link>
              </div>
            </div>

            {/* Direct Flights Card */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image 
                  src="/images/slide_15_image_1.png" 
                  alt="Direct Flights Impact" 
                  fill 
                  style={{objectFit: 'cover'}}
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Direct Flights Influence on Tourism</h3>
                <p className="text-gray-600 mb-4">
                  Discover how the availability of direct flights correlates with tourism growth across different regions.
                </p>
                <Link href="/direct-flights" className="text-blue-600 font-semibold hover:underline">
                  Explore Impact →
                </Link>
              </div>
            </div>

            {/* Currency Strength Card */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image 
                  src="/images/slide_18_image_1.png" 
                  alt="Currency Strength Impact" 
                  fill 
                  style={{objectFit: 'cover'}}
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Currency Strength Impact on Travel</h3>
                <p className="text-gray-600 mb-4">
                  Analyze how currency fluctuations affect tourism patterns and visitor numbers around the world.
                </p>
                <Link href="/currency-impact" className="text-blue-600 font-semibold hover:underline">
                  Explore Correlation →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Target Audience Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">Who Benefits from These Insights?</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-6 border border-gray-200 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Government & Policy Makers</h3>
              <p className="text-gray-600">
                Make informed economic and strategic decisions based on comprehensive tourism data and trends.
              </p>
            </div>
            
            <div className="p-6 border border-gray-200 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Travel & Hospitality Industry</h3>
              <p className="text-gray-600">
                Hotels, airlines, and tourism boards can use these insights for marketing and business planning.
              </p>
            </div>
            
            <div className="p-6 border border-gray-200 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Curious Travelers & Digital Nomads</h3>
              <p className="text-gray-600">
                Discover new destinations and understand how global factors influence travel opportunities.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12 mt-auto">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Global Tourism Insights</h3>
              <p className="text-gray-300">
                An interactive exploration of tourism data based on the DATASCI209 Midterm Presentation.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Data Sources</h3>
              <p className="text-gray-300">
                UN Tourism Statistics, including Inbound Tourism, Domestic Tourism, Outbound Tourism, 
                Tourism Industries, and Macroeconomics Indicators.
              </p>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>© 2025 Global Tourism Insights. Created for educational purposes.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
