"use client"

import { useState } from 'react';
import { ResponsiveLine } from '@nivo/line'
import { ResponsiveBar } from '@nivo/bar'
import { ResponsiveGeoMap } from '@nivo/geo'
import Link from 'next/link'
import Image from 'next/image'

// Sample data for tourism trends visualization
const tourismTrendsData = [
  {
    id: "Global Tourism Arrivals",
    data: [
      { x: "1995", y: 980 },
      { x: "1996", y: 1050 },
      { x: "1997", y: 1120 },
      { x: "1998", y: 1080 },
      { x: "1999", y: 1100 },
      { x: "2000", y: 1150 },
      { x: "2001", y: 1140 },
      { x: "2002", y: 1160 },
      { x: "2003", y: 1200 },
      { x: "2004", y: 1450 },
      { x: "2005", y: 1550 },
      { x: "2006", y: 1700 },
      { x: "2007", y: 1650 },
      { x: "2008", y: 1600 },
      { x: "2009", y: 1650 },
      { x: "2010", y: 1700 },
      { x: "2011", y: 1750 },
      { x: "2012", y: 1800 },
      { x: "2013", y: 1850 },
      { x: "2014", y: 1900 },
      { x: "2015", y: 1950 },
      { x: "2016", y: 2000 },
      { x: "2017", y: 2100 },
      { x: "2018", y: 2200 },
      { x: "2019", y: 2300 },
      { x: "2020", y: 700 },
      { x: "2021", y: 800 },
      { x: "2022", y: 1100 },
    ]
  }
]

export default function TourismTrends() {
  const [selectedYear, setSelectedYear] = useState("2019")
  
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-blue-600 text-white py-6">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <Link href="/" className="text-2xl font-bold">Global Tourism Insights</Link>
            <nav className="flex gap-6">
              <Link href="/tourism-trends" className="font-semibold underline">Tourism Trends</Link>
              <Link href="/direct-flights" className="font-semibold">Direct Flights Impact</Link>
              <Link href="/currency-impact" className="font-semibold">Currency Strength Impact</Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        {/* Section Header */}
        <section className="bg-blue-50 py-12">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl font-bold mb-4">Tourism Trends Over the Past Decade</h1>
            <p className="text-xl text-gray-600">
              Explore how global tourism has evolved from 1995 to 2022, including the significant impact of COVID-19.
            </p>
          </div>
        </section>

        {/* Tourism Arrivals Line Chart */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="bg-white rounded-xl shadow-md p-6 mb-8">
              <h2 className="text-2xl font-bold mb-6">Global Tourism Arrivals (1995-2022)</h2>
              <div className="h-[500px]">
                <ResponsiveLine
                  data={tourismTrendsData}
                  margin={{ top: 50, right: 110, bottom: 50, left: 60 }}
                  xScale={{ type: 'point' }}
                  yScale={{
                    type: 'linear',
                    min: 0,
                    max: 2500,
                    stacked: false,
                  }}
                  curve="monotoneX"
                  axisTop={null}
                  axisRight={null}
                  axisBottom={{
                    tickSize: 5,
                    tickPadding: 5,
                    tickRotation: -45,
                    legend: 'Year',
                    legendOffset: 45,
                    legendPosition: 'middle'
                  }}
                  axisLeft={{
                    tickSize: 5,
                    tickPadding: 5,
                    tickRotation: 0,
                    legend: 'Arrivals (thousands)',
                    legendOffset: -50,
                    legendPosition: 'middle'
                  }}
                  colors={{ scheme: 'blues' }}
                  pointSize={10}
                  pointColor={{ theme: 'background' }}
                  pointBorderWidth={2}
                  pointBorderColor={{ from: 'serieColor' }}
                  pointLabelYOffset={-12}
                  useMesh={true}
                  legends={[
                    {
                      anchor: 'bottom-right',
                      direction: 'column',
                      justify: false,
                      translateX: 100,
                      translateY: 0,
                      itemsSpacing: 0,
                      itemDirection: 'left-to-right',
                      itemWidth: 80,
                      itemHeight: 20,
                      itemOpacity: 0.75,
                      symbolSize: 12,
                      symbolShape: 'circle',
                      symbolBorderColor: 'rgba(0, 0, 0, .5)',
                      effects: [
                        {
                          on: 'hover',
                          style: {
                            itemBackground: 'rgba(0, 0, 0, .03)',
                            itemOpacity: 1
                          }
                        }
                      ]
                    }
                  ]}
                  annotations={[
                    {
                      type: 'point',
                      x: '2020',
                      y: 700,
                      note: 'COVID-19 Impact',
                      noteX: 10,
                      noteY: -25,
                      noteTextOffset: -10,
                      noteWidth: 100,
                    }
                  ]}
                />
              </div>
              <div className="mt-4 text-gray-600">
                <p>This chart shows the global tourism arrivals from 1995 to 2022. Note the significant drop in 2020 due to the COVID-19 pandemic, followed by a gradual recovery in subsequent years.</p>
              </div>
            </div>
          </div>
        </section>

        {/* International Arrivals Map */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-2xl font-bold mb-6">International Arrivals Map</h2>
              
              {/* Year Selector */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Select Year:</label>
                <select 
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(e.target.value)}
                  className="block w-full max-w-xs px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="2009">2009</option>
                  <option value="2019">2019</option>
                </select>
              </div>
              
              {/* Map Visualization */}
              <div className="h-[600px] relative">
                <Image 
                  src={selectedYear === "2009" ? "/images/slide_9_image_1.png" : "/images/slide_9_image_2.png"}
                  alt={`International Arrivals Map ${selectedYear}`}
                  fill
                  style={{objectFit: 'contain'}}
                />
              </div>
              
              <div className="mt-6 text-gray-600">
                <p>This map shows international tourism arrivals by country for the selected year. Countries with darker blue colors received more international visitors.</p>
                <p className="mt-2">The original interactive map is available on <a href="https://public.tableau.com/shared/P94Q4RTHB?:display_count=n&:origin=viz_share_link" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Tableau Public</a>.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Key Insights */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8">Key Insights</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Long-term Growth Trend</h3>
                <p className="text-gray-600">
                  Global tourism showed consistent growth from 1995 to 2019, with international arrivals more than doubling during this period. This reflects increasing global mobility, rising middle classes in developing countries, and the growing importance of tourism to the global economy.
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">COVID-19 Impact</h3>
                <p className="text-gray-600">
                  The COVID-19 pandemic caused an unprecedented drop in global tourism in 2020, with arrivals falling by approximately 70% compared to 2019. This represents the largest disruption to global tourism in modern history, far exceeding previous crises like the 2008 financial crisis or the SARS outbreak.
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Recovery Patterns</h3>
                <p className="text-gray-600">
                  The data shows a gradual recovery beginning in 2021 and continuing into 2022, though arrivals remained well below pre-pandemic levels. The recovery has been uneven across regions, with some destinations recovering faster than others based on factors like vaccination rates and travel restrictions.
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Regional Variations</h3>
                <p className="text-gray-600">
                  The map visualization reveals significant regional variations in tourism arrivals. Europe and parts of Asia consistently receive the highest number of international visitors, while many regions in Africa and parts of South America receive fewer international tourists despite having significant tourism potential.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <p>© 2025 Global Tourism Insights</p>
            </div>
            <div className="flex gap-8">
              <Link href="/" className="hover:underline">Home</Link>
              <Link href="/tourism-trends" className="hover:underline">Tourism Trends</Link>
              <Link href="/direct-flights" className="hover:underline">Direct Flights Impact</Link>
              <Link href="/currency-impact" className="hover:underline">Currency Strength Impact</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
