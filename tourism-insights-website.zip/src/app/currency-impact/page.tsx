"use client"

import { useState } from 'react';
import { ResponsiveGeoMap } from '@nivo/geo'
import { ResponsiveLine } from '@nivo/line'
import Link from 'next/link'
import Image from 'next/image'

export default function CurrencyImpact() {
  const [selectedYear, setSelectedYear] = useState("2019")
  
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-blue-600 text-white py-6">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <Link href="/" className="text-2xl font-bold">Global Tourism Insights</Link>
            <nav className="flex gap-6">
              <Link href="/tourism-trends" className="font-semibold">Tourism Trends</Link>
              <Link href="/direct-flights" className="font-semibold">Direct Flights Impact</Link>
              <Link href="/currency-impact" className="font-semibold underline">Currency Strength Impact</Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        {/* Section Header */}
        <section className="bg-blue-50 py-12">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl font-bold mb-4">Currency Strength Impact on Travel</h1>
            <p className="text-xl text-gray-600">
              Analyze how currency fluctuations affect tourism patterns and visitor numbers around the world.
            </p>
          </div>
        </section>

        {/* Filters Panel */}
        <section className="py-6 bg-white border-b">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap gap-6 items-end">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Year:</label>
                <select 
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(e.target.value)}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="2017">2017</option>
                  <option value="2018">2018</option>
                  <option value="2019">2019</option>
                  <option value="2020">2020</option>
                  <option value="2021">2021</option>
                </select>
              </div>
            </div>
          </div>
        </section>

        {/* Side-by-Side Maps */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="bg-white rounded-xl shadow-md p-6 mb-8">
              <h2 className="text-2xl font-bold mb-6">World View of Currency and Visitors</h2>
              
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Visitor Percent Change</h3>
                  <div className="h-[400px] relative">
                    <Image 
                      src="/images/slide_18_image_2.png"
                      alt="Visitor Percent Change"
                      fill
                      style={{objectFit: 'contain'}}
                    />
                  </div>
                  <div className="mt-2 text-sm text-gray-600">
                    <p>Blue = More visitors than previous year</p>
                    <p>Red = Less visitors than previous year</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-4">Currency Percent Change</h3>
                  <div className="h-[400px] relative">
                    <Image 
                      src="/images/slide_18_image_1.png"
                      alt="Currency Percent Change"
                      fill
                      style={{objectFit: 'contain'}}
                    />
                  </div>
                  <div className="mt-2 text-sm text-gray-600">
                    <p>Blue = USD strengthened vs currency</p>
                    <p>Red = USD weakened vs currency</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 text-gray-600">
                <p>These maps show the relationship between currency strength changes and visitor numbers. The left map shows changes in visitor numbers compared to the previous year, while the right map shows currency percent changes relative to the USD.</p>
                <p className="mt-2">When comparing these maps, you can observe patterns that suggest how currency strength may influence tourism decisions. For example, many European countries experienced both a strengthening USD (making travel cheaper for Americans) and an increase in visitors.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Currency-Tourism Correlation */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-2xl font-bold mb-6">Currency-Tourism Correlation</h2>
              <div className="h-[500px] relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-gray-500 mb-4">Interactive scatter plot visualization</p>
                    <p className="text-gray-700 font-medium">Y-axis: Tourism percent change from previous year</p>
                    <p className="text-gray-700 font-medium">X-axis: Currency percent change compared to USD</p>
                    <p className="text-gray-500 mt-4">Positive X values indicate USD strengthened relative to local currency</p>
                  </div>
                </div>
              </div>
              <div className="mt-4 text-gray-600">
                <p>This scatter plot explores the potential correlation between currency strength and tourism. Each point represents a country, with the y-axis showing the tourism percent change from the previous year and the x-axis showing the currency percent change compared to the USD.</p>
                <p className="mt-2">A positive correlation would suggest that as a country's currency weakens against the USD (making it cheaper for American tourists), tourism increases. However, the relationship is complex and varies by region and other factors.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Competing Hypotheses */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8">Exploring the Impact of Currency on Tourism</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Hypothesis 1: Weaker Currency Attracts More Visitors</h3>
                <p className="text-gray-600">
                  When a currency loses value, foreigners have more purchasing power in that country, making it a more affordable destination. This increased affordability may attract more tourists looking to maximize their travel budget.
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Hypothesis 2: Weaker Currency Indicates Instability</h3>
                <p className="text-gray-600">
                  A weakening currency might signal economic or political instability in a country, which could discourage potential visitors concerned about safety, infrastructure, or service quality. This would lead to a decrease in tourism despite the better exchange rates.
                </p>
              </div>
            </div>
            
            <div className="mt-8 bg-white rounded-xl shadow-md p-6">
              <h3 className="text-xl font-bold mb-4">Analysis Findings</h3>
              <p className="text-gray-600 mb-4">
                The data presents evidence supporting both hypotheses, suggesting that the relationship between currency strength and tourism is complex and influenced by multiple factors:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-600">
                <li>Many European countries saw increased tourism when the USD strengthened against their currencies, supporting Hypothesis 1.</li>
                <li>However, countries like Russia, Brazil, Chile, and Somalia saw decreases in visitors despite the USD rising in comparative strength against their currencies, supporting Hypothesis 2.</li>
                <li>The correlation appears to be stronger in regions with established tourism infrastructure and political stability.</li>
                <li>Other factors such as visa policies, marketing efforts, and global events also significantly influence tourism patterns.</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Key Insights */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8">Key Insights</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Regional Variations</h3>
                <p className="text-gray-600">
                  The impact of currency strength on tourism varies significantly by region. Established tourism destinations in stable economies tend to benefit more from currency weakening, while developing destinations may be more negatively affected by the perception of instability.
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Multiple Influencing Factors</h3>
                <p className="text-gray-600">
                  Currency strength is just one of many factors affecting tourism decisions. Safety perceptions, visa requirements, direct flight availability, and destination marketing all play significant roles in determining tourism patterns.
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Implications for Tourism Boards</h3>
                <p className="text-gray-600">
                  Tourism boards in countries experiencing currency weakening can potentially capitalize on increased affordability by targeting marketing efforts toward countries with stronger currencies. However, they must also address any perceptions of instability.
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold mb-4">Opportunities for Travelers</h3>
                <p className="text-gray-600">
                  For travelers, understanding currency trends can help identify destinations where their money will go further. Countries with recently weakened currencies but stable tourism infrastructure may offer particularly good value.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <p>© 2025 Global Tourism Insights</p>
            </div>
            <div className="flex gap-8">
              <Link href="/" className="hover:underline">Home</Link>
              <Link href="/tourism-trends" className="hover:underline">Tourism Trends</Link>
              <Link href="/direct-flights" className="hover:underline">Direct Flights Impact</Link>
              <Link href="/currency-impact" className="hover:underline">Currency Strength Impact</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
